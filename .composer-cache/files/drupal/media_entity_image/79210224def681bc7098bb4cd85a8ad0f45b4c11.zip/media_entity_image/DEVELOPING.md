# Developing

* Issues should be filed at http://drupal.org/project/issues/media_entity_image
* Pull requests can be made against https://github.com/drupal-media/media_entity_image/pulls
