<?php

/**
 * @file
 * Contains \Drupal\layout_plugin\Plugin\Layout\LayoutDefault.
 */

namespace Drupal\layout_plugin\Plugin\Layout;


/**
 * Provides a default class for Layout plugins.
 */
class LayoutDefault extends LayoutBase {

}
